﻿#include "C:\Users\Usman Bari\Desktop\3 game\3 game\oop_project - Copy\official.h"

int main()
{
    GameBoy gameboy;
    gameboy.run();
    return 0;
}